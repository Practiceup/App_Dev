const express = require('express')
const bodyParse = require('body-parser')
const mongoose = require('mongoose')

// Create app using express
const app = express()

app.use(bodyParse.json())
app.use(express.static('public'))
app.use(bodyParse.urlencoded({ extended: true }))

// Connect to database
mongoose.connect('mongodb://127.0.0.1/userlogin', { useNewUrlParser: true, useUnifiedTopology: true })

// Check connection
const db = mongoose.connection
db.once('open', () => { console.log("Connected to the database") })
db.on('error', (error) => { console.log("Error Connecting", error) })

// Create loading page
app.get('/', (req, res) => {
    res.redirect('index.html')
}).listen(3000)

// Posting form
app.post('/login', (request, response) => {
    try {
        // get data from index.html
        const username = request.body.username
        const password = parseInt(request.body.password)

        // test the app is reading the username and password
        // console.log(`entered username = ${username} entered password ${password}`)

        // get data from database
        const usermail = db.collection('users').findOne({ username: username }, (err, res) => {
            if (res === null) {
                response.send('Information does not match')
            } else if (err) {
                throw err
            }

            if (res.password === password) {
                console.log("Login successful!")
                return response.redirect('login.html')
            } else {
                console.log("Password doesn't match")
                response.send("PASSWORD DOESN'T MATCH")
            }
        })
    } catch (error) {
        console.log("Invalid information")
    }
})



// npm install express body-parser mongoose nodemon
// issue with node 17+: change localhost to 127.0.0.1 to fix
