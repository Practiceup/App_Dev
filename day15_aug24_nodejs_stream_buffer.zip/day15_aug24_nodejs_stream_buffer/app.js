// Streams and Bufferd
// const fs = require('fs')

// const http = require('http')

// Create readable stream to read file readme.txt
// const readStream = fs.createReadStream('readme.txt')
// const writestream = fs.createWriteStream('write.txt')

// Create server
// const server = http.createServer((request, response) => {
//     // sending the response
//     readStream.pipe(response)

// })


// Listen to the stream to read file readme.txt
// readStream.on('data', (d) => {
//     console.log("\n---------------new data received-------------\n")
//     console.log(d)
//     console.log("\n---------------------------------------------\n")
//     writestream.write(d)
// })

// readStream.on('open', () => {
//     console.log("\n\nStream opened")
// })

// readStream.on('end', () => {
//     console.log("Stream closed!... \n\n")
// })

// createWriteStream
// const writestream = fs.createWriteStream('write.txt')
// writestream.write('Streaming text content', 'utf-8')


// // Import http module

// const http = require('http')

// // Create server
// const server = http.createServer((request, response) => {
//     // sending the response
//     response.write("This is the response from the server")
//     response.end("\n----- end ----")
//     console.log(request.url)
// })

const fs = require('fs')
const http = require('http')

// const readStream = fs.createReadStream('index.html')
const writestream = fs.createWriteStream('write.txt')

const server = http.createServer((request, response) => {
    // sending the response
    response.writeHead(200, { 'Content-Type': 'text/html' })
    const url = request.url

    if (url === '/home' || url === '/') {
        fs.createReadStream('index.html').pipe(response)
    } else if (url === '/about') {
        fs.createReadStream('about.html').pipe(response)
    } else {
        fs.createReadStream('404.html').pipe(response)
    }
    // readStream.pipe(response)

})




// // Server listening
server.listen((3000), () => {
    console.log("Server is running at localhost:3000")
})