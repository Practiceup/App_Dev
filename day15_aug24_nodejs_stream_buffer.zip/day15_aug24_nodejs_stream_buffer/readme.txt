Data About New York City
New York City comprises 5 boroughs sitting where the Hudson River meets the Atlantic Ocean. At its core is Manhattan, a densely populated borough that’s among the world’s major commercial, financial and cultural centers. Its iconic sites include skyscrapers such as the Empire State Building and sprawling Central Park. Broadway theater is staged in neon-lit Times Square. ― Google
Area codes: 212/646/332, 718/347/929, 917
GMP (2021): $2.0 trillion (1st)
Largest borough by area: Queens (109 sq mi or 280 km2)
Named for: James, Duke of York
Region: Mid-Atlantic
Settled: 1624 (399 years ago)
ZIP Codes: 100xx–104xx, 11004–05, 111xx–114xx, 116xx