export class Shopper {
  constructor(
      public id?: number,
      public name?: string,
      public email?: string,
      public quantity?: number,
      public total?: number
  )
  {}
}