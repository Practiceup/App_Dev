import { Component } from '@angular/core';

@Component({
  selector: 'shopper',
  templateUrl: './shopper.component.html',
  styleUrls: ['./shopper.component.css'],
})
export class ShopperComponent {}
