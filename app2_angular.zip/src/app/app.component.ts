import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'app2_angular';

  prod1: string = 'Product 1 added';
  quantity: number = 20;
  price: number = 69.99;
  totalProd1Added: number = 0;
  btnDisabled: boolean = false;
  btnProdText: string = 'Add to Bag';
  totalCost: number = 0;
  addItem() {
    this.quantity--;
    this.totalProd1Added++;
    this.totalCost = parseFloat(this.price.toFixed(2)) * this.totalProd1Added;
    if (this.quantity == 0) {
      this.btnDisabled = true;
      this.btnProdText = 'OUT OF STOCK!';
    }
  }
}
