import { User } from './user.model';
import { dataSource } from './dataSource.model';

export class UserRepository {
  private dataSource: dataSource;
  private users: User[];

  constructor() {
    this.dataSource = new dataSource();
    this.users = new Array<User>();
    this.dataSource.getUser().forEach((u) => this.users.push(u));
  }

  getUsers(): User[] {
    return this.users;
  }

  getUserId(id: number): any {
    return this.users.find((u) => u.id == id);
  }

  addUser(user: User) {
    this.users.push(user);
  }
}
