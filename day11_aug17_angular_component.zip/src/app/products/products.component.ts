import { Component } from '@angular/core';

@Component({
  selector: 'products', //selecting a <products></products> tag
  templateUrl: './products.component.html',
})
export class ProductsComponent {}

// ng serve --open
