const helper = function (data) {
    return `${data} is logged in!`
}

const id = function (i) {
    return `${i}`
}

let email = function (e) {
    return e;
}


// ONE-LINE EXPORTS
module.exports = { helper, id, email }

// INDIVIDUAL EXPORTS

// module.exports.helper = helper
// module.exports.id = id
// module.exports.email = email