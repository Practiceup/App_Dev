const { error } = require('console')
const fs = require('fs')

fs.rmdirSync("newDir") // <-- Will remove directory

fs.mkdirSync("newDir")  //<--Will result in error if run more than once

fs.mkdir("images", function (e) {
    if (e) {
        console.log(e)
    }
    console.log("Directory created successfully!")
})

// CREATE A SYNCHRONOUS FILE USING writeFileSync()
// syntax:
// fs.writeFileSync(file, data, options)
let fileContent = "This file has three name: \n1. Peter\n2. Martha\n3. Jason"
fs.writeFileSync('write.txt', fileContent, 'utf-8')

// CREATE AN ASYNCHRONOUS FILE USING writeFile
let msg = "Welcome to Node.js I/O files"
fs.writeFile("msg.txt", msg, "utf-8", function (e) {
    if (e) {
        console.log(e)
    }
})

// APPEND INFORMATION TO EXISTING FILE
// fs.writeFileSync("write.txt", "HELLO!", "utf-8")  <-- Will override sontents of file
// let addNames = "\n4. George\n5. Ann"
// fs.appendFileSync("write.txt", addNames, "utf-8")

// APPEND USING ASYNCHRONOUS METHOD
let addNames = "4. George\n5. Ann"
fs.appendFileSync("write.txt", addNames, "utf-8", function (error) {
    if (error) {
        console.log(error)
    }
})

// REMOVE AN EXISTING FILE ASYNCHRONOUSLY
fs.unlink("msg.txt", function (error) {
    console.log(error)
})

// ASYNCHRONOUS READ MODULE
console.log('Line before readFile')
fs.readFile('readme.txt', 'utf-8', function (error, data) {
    console.log('\n\n----async read file ----')
    console.log(data)
})
console.log("Line after readFile")

let sum = 5 + 20
console.log(`Sum = ${sum}`)

// SYNCHRONOUS READ MODULE
console.log('\n\nLine before readFileSync')

let fileRead = fs.readFileSync('readme.txt', 'utf-8')
console.log(fileRead)

console.log('Line after readFileSync')

// node readwrite to run file