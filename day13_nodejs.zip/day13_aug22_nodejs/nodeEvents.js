const events = require('events')
const util = require('util')

const teams = function (name) {
    this.name = name
}

// EventEmitter will inherit any of teams in the constructor
util.inherits(teams, events.EventEmitter)

const Barcelona = new teams('Barcelona')
const Milan = new teams('Milan')

// SAVE EACH CONSTRUCTOR IN AN ARRAY
const teamsArray = [Barcelone, Milan]

// PRINT EACH TEAM USING forEach LOOP
teamsArray.forEach((t) => {
    t.on('nation', function (n) {
        console.log(t.name + " is " + n + "soccer club!")
    })
})

// EMIT THE eventEmitter
Milan.emit('nation', 'Italian')
Barcelona.emit('nation', 'Spain')

// Events module
const eventEmitter = new events.EventEmitter
eventEmitter.on('test', function (a) {
    console.log(a)
})

eventEmitter.emit('test', 'EVENTS IN NODEJS')