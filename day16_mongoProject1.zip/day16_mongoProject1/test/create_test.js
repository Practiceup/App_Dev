// assert is used to compare two boolean values. It is used in mocha to test data before sending data to the db. If assert returns True, the data will be sent to the db
const assert = require('assert')
const Student = require('../src/students')

// Create description function
// describe('Create the first data', () => {
//     it('Save the student', () => {
//         assert((2 + 8) === 10)
//     })
// })

// Go to json file, change "test" to "test": "mocha"
// Run test - npm run test

describe('Create the first data', (done) => {
    it('Saves the student', () => {
        // Create the new student
        const student1 = new Student({ name: 'Peter' })
        //  Create/save the new student in the db
        student1.save()
            .then(() => {
                assert(!student1.isNew)
                done()
            })
    })
})
