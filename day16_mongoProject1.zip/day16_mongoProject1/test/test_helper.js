// import mongoose
const mongoose = require('mongoose')

// Connect to the database, student_test database (Will create one if it doesn't exist)
mongoose.connect('mongodb://127.0.0.1/students_test')

// Check if it is connected
mongoose.connection

    // .once method watches for mongoDB to connect the first time once an event occured
    .once('open', () => {
        console.log('\n ----- Connected to mongoDB ----- \n')
    })
    // .on watches for error in the connection
    .on('err', (e) => {
        console.log('Error connecting...', e)

    })
// cd into project folder. run node test/test_helper

// Clear previous db actions
beforeEach((done) => {
    mongoose.connection.collections.students.drop()
    done()
})