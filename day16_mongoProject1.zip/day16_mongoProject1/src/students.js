// Import modules
const mongoose = require('mongoose')
const Schema = mongoose.Schema

// Config the schema
const StudentSchema = new Schema({
    name: String,
    studentNumber: Number
})

// Create the model schema for each student
const Student = mongoose.model('student', StudentSchema)

module.exports = Student