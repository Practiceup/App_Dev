import '../App.css';
import React, { Component } from 'react'
import HemisphereDisplay from '../components/HemisphereDisplay'

class App extends Component {

    state = { latitude: '' }
    componentDidMount() {
        window.navigator.geolocation.getCurrentPosition(
            (position) => {
                this.setState({ latitude: position.coords.latitude })
            }
        )
    }

    render() {
        return (
            <div>
                <h1>Geolocation</h1>
                <p>Latitude = <span>{this.state.latitude}</span></p>
                <HemisphereDisplay latitude={this.state.latitude} />
            </div>
        );
    }
}

export default App;
