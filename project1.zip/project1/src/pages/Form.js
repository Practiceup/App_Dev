// import './App.css';
import { useState } from "react"

function Form() {
    // useState
    const [inputs, setInputs] = useState("Peter")

    // inputs data
    const handleChange = function (e) {
        const name = e.target.name
        const value = e.target.value
        setInputs(values => ({
            ...values, [name]: value
        }))
    }

    // SELECT DATA
    const [myGender, setmyGender] = useState('female')
    const selectedGender = function (e) {
        setmyGender(e.target.value)
    }

    // TEXT AREA
    const [textComments, setTextarea] = useState('')
    const submitComment = function (e) {
        setTextarea(e.target.value)
    }

    // Submit form
    const handleSubmit = function (e) {
        e.preventDefault();
        alert(`The name: ${inputs.username} \nEntered age: ${inputs.enteredAge} \nGender: ${myGender} \nComments: ${textComments}`)
    }


    return (
        <div className="App">
            <form className='ui form' onSubmit={handleSubmit}>
                <fieldset>
                    <legend>Forms in ReactJS</legend>
                    <label for='name'>Enter your name: </label>
                    <input
                        type="text"
                        placeholder="Type your name..."
                        id="name"
                        name="username"
                        value={inputs.username}
                        onChange={handleChange}
                    />
                    <label for='age'>Enter age: </label>
                    <input
                        type='number'
                        placeholder='Enter you age'
                        id='age'
                        name='enteredAge'
                        value={inputs.enteredAge}
                        onChange={handleChange}
                    />
                    <div style={{ marginTop: "1em" }}>
                        <label>Select gender:
                            <select value={myGender} onChange={selectedGender}>
                                <option value='female'>Female</option>
                                <option value='male'>Male</option>
                                <option value='other'>Othe</option>
                            </select>
                        </label>
                    </div>
                    <div style={{ maginTop: "1em" }}>
                        <textarea
                            value={textComments}
                            onChange={submitComment}
                            placeholder='Enter your comment'
                        />
                    </div>
                    <div style={{ marginTop: "1em" }}>
                        <input type="submit" className='ui button' />
                    </div>

                </fieldset>
            </form>

        </div>
    );
}

export default Form;
