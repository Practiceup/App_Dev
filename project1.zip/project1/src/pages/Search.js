import React, { createContext, useState } from 'react'
import SearchHead from '../components/SearchHead'
import SearchInput from '../components/SearchInput'
import Images from '../components/Images'
import useAxios from '../hooks/useAxios'

export const ImageContext = createContext();

function Search() {
    const [searchImage, setSearchImage] = useState("");
    const { response, isLoading, error, fetchData } = useAxios(`search/photos?page=1&query=cats&client_id=${process.env.REACT_APP_API_KEY}`)

    const value = {
        response,
        isLoading,
        error,
        fetchData,
        searchImage,
        setSearchImage
    }

    return (
        <ImageContext.Provider value={value}>
            <SearchHead>
                <SearchInput />
            </SearchHead>
            <Images />
        </ImageContext.Provider>
    )
}

export default Search

