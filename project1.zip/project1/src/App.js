import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Form from '../src/pages/Form';
import Home from '../src/pages/Home';
import NavBar from './components/NavBar';
import Hemisphere from '../src/pages/Hemisphere';
import Search from '../src/pages/Search';

function App() {
  return (
    <div className='App'>
      <BrowserRouter>
        <NavBar />
        <Routes>
          <Route path='/' element={<NavBar />} />
          <Route index element={<Home />} />
          <Route path='/search' element={<Search />} />
          <Route path='/hemisphere' element={<Hemisphere />} />
          <Route path='/form' element={<Form />} />
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App;