import React, { useContext } from 'react'
import { ImageContext } from '../pages/Search'
import Image from './Image'
import Skeleton from './Skeleton'

function Images() {
  const { response, isLoading, searchImage } = useContext(ImageContext)
  return (
    <>
      <h1 style={{ textAlign: "center", marginTop: "6px", textDecoration: "underline" }}>Results for {searchImage || "Cats"}</h1>
      <div className="imagesDiv" style={{ display: "flex", flexWrap: "wrap", gap: "8px", maringTop: "20px", maxWidth: "80rem", marginTop: "auto", marginBottom: "auto", padding: "0 4px", justifyContent: "center" }}>
        {isLoading ? <Skeleton item={12} /> : response.map((data, key) => <Image key={key} data={data} />)}
      </div>
    </>
  )
}

export default Images