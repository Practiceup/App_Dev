import React from 'react'

function Image({ data }) {
    return (
        <a href={data.urls.regular} target='_blank' rel='noreferrer'>
            <img src={data.urls.small} alt={data.alt_description} style={{ height: "18rem", width: "100%", objectFit: "contain", borderRadius: "8px", boxShadow: "2px 2px grey" }} />
        </a>
    )
}

export default Image