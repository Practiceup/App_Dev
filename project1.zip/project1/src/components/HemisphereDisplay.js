import React, { Component } from 'react';
import northern from '../images/Northern_Hemisphere.png';
import southern from '../images/Southern_Hemisphere.png';
import ecuadorian from '../images/Ecuadorian.png';

class HemisphereDisplay extends Component {
    render() {
        const hemisphereResult = this.props.latitude;
        let userLocation = '';
        let picture = northern;
        let author = '';

        if (hemisphereResult > 0) {
            userLocation = 'Northern Hemisphere!';
            picture = northern;
            author = 'By Sean Baker';
        } else if (hemisphereResult < 0) {
            userLocation = 'Southern Hemisphere';
            picture = southern;
            author = 'By Sean Baker';
        } else {
            userLocation = 'the Ecuadorian line!';
            picture = ecuadorian;
            author = 'By Wikimedia Commons contributors';
        }

        return (
            <div>
                <h1>Welcome to the hemisphere app</h1>
                <p>You are at <span>{userLocation}</span></p>
                <img src={picture} style={{ width: '50%' }} alt="Hemisphere" />
                <p>{author}</p>
            </div>
        );
    }
}

export default HemisphereDisplay;
