import React, { useContext, useState } from 'react'
import { ImageContext } from '../pages/Search';

function SearchInput({ children }) {
    const [searchValue, setSearchValue] = useState("");
    const { fetchData, setSearchImage } = useContext(ImageContext);

    const handleChange = (e) => {
        setSearchValue(e.target.value);
    }

    const handleSubmit = () => {
        fetchData(`search/photos?page=1&query=${searchValue}&client_id=${process.env.REACT_APP_API_KEY}`)
        setSearchValue("");
        setSearchImage(searchValue)
    }

    const handleKey = e => {
        if (e.key === "Enter") {
            fetchData(`search/photos?page=1&query=${searchValue}&client_id=${process.env.REACT_APP_API_KEY}`)
            setSearchValue("");
            setSearchImage(searchValue)
        }
    }

    return (
        <div style={{ display: "flex", justifyContent: "center" }} >
            <input
                type='search'
                style={{ border: "1px solid grey", padding: "2.5px", borderRadius: "5px 0 0 5px" }}
                placeholder='Search...'
                value={searchValue}
                onChange={handleChange}
                onKeyDown={handleKey}
            />
            <button
                onClick={handleSubmit}
                disabled={!searchValue}
                style={{ backgroundColor: "blue", padding: "6px 2.5px", color: "white", borderRadius: "0 5px 5px 0", cursor: "pointer" }}>Search</button>
        </div>
    )
}

export default SearchInput

