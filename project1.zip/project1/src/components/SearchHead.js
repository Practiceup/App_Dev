import React from 'react'

function SearchHead({ children }) {
    return (
        <div>
            <div>
                <h1 className='ui title' style={{ textAlign: "center", color: "goldenrod" }}>Welcome To Image Search</h1>
                {children}
            </div>
        </div>
    )
}

export default SearchHead

