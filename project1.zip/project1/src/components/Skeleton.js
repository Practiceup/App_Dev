import React from 'react'

function Skeleton({ item }) {
    return [...Array(item).keys()].map(() => (
        <div>
            <div style={{ backgroundColor: "grey", borderRadius: "8px", height: "18rem" }}>

            </div>
        </div>
    ))
}

export default Skeleton