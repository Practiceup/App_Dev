import React from 'react'
import { Link, Outlet } from "react-router-dom";


function NavBar() {
    // const hamburger = document.querySelector(".hamburger");
    // const navMenu = document.querySelector(".nav-menu");

    // hamburger.addEventListener("click", () => {
    //     hamburger.classList.toggle("active");
    //     navMenu.classList.toggle("active");
    // })

    // document.querySelectorAll(".nav-link").forEach(n => n.addEventListener("click", () => {
    //     hamburger.classList.remove("active");
    //     navMenu.classList.remove("active");
    // }))
    return (
        <header>
            <nav className='navbar'>
                <a href='#' className='branding'>Welcome</a>

                <ul className='nav-menu'>
                    <li className='nav-item'>
                        <Link className="nav-link" to={'/'}>Home</Link>
                    </li>
                    <li className='nav-item'>
                        <Link className="nav-link" to={'/search'}>Image Search</Link>
                    </li>
                    <li className='nav-item'>
                        <Link className="nav-link" to={'/hemisphere'}>Hemisphere Display</Link>
                    </li>
                    <li className='nav-item'>
                        <Link className="nav-link" to={'/form'}>Forms</Link>
                    </li>
                </ul>
                <div className='hamburger'>
                    <span className='bar'></span>
                    <span className='bar'></span>
                    <span className='bar'></span>
                </div>
            </nav>
            <Outlet />
        </header>
    )
}

export default NavBar